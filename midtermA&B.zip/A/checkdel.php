<?php
$no=$_GET["no"];
echo $no;

$link=mysqli_connect("localhost","root","Lui1995#","midterm");
$del="DELETE FROM user WHERE no=".$no;
mysqli_query($link,$del);

$read="SELECT * FROM user";
$readresult=mysqli_query($link,$read);
	echo "<table border=''>";
	echo "<tr><td>帳號</td><td>密碼</td> <td>EMail</td> <td>電話號碼</td> <td>更新資料</td><td>刪除資料</td></tr>";
while($result=mysqli_fetch_array($readresult)){
	echo "<tr>";
	echo "<td>".$result[1]."</td><td>".$result[2]."</td> <td>".$result[3]."</td> <td>".$result[4]."</td>";
	echo "<td><a href='update?no=".$result[0]."'>更新資料</td>";
	echo "<td><a href='checkdel.php?no=".$result[0]."'>刪除資料</a></td>";
	echo "</tr>";
}
	echo "</table>";
?>
<p><a href="index.php">回頁面</a></p>