<?php
session_start();
$counter=1;

require('include.inc');
$sql = 'CREATE DATABASE travel DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci';

mysqli_select_db($link,"midterm");
$sql = "select * from user WHERE uid =".$uid;
mysqli_query($link,$sql);

$read="SELECT * FROM user";
$readresult=mysqli_query($link,$read);
  
  while($row = mysqli_fetch_array($readresult))
  {
   echo $row["1"]." ";
   echo "歡迎回來！";
  }

if(isset($_COOKIE['counter'])){
	if(isset($_SESSION['entered']))
		$counter=$_COOKIE['counter'];
	else
		$counter=$_COOKIE['COUNTER']+1;
}

setcookie("counter",$counter, time()+30*24);
echo "你的登入次數為$counter！";

echo "</br>";

echo "<a href='profile.php'>去修改頁面";

?>