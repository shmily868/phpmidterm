<html>
<head>
<title>註冊</title>
<meta charset="UTF-8"/>
</head>
<SCRIPT type="text/javascript">
        function check()
        {
                if(reg.uid.value == "") 
                {
                        alert("未輸入姓名");
                }
                else if(reg.upwd.value == "")
                {
                        alert("未輸入密碼");
                }
                else if(reg.email.value == "")
                {
                        alert("未輸入電子郵件");
                }
                else if(reg.phnum.value == "")
                {
                         alert("未輸入電話號碼");
                }
                else reg.submit();
         }
</SCRIPT>

<body>
<form name="reg" action="" method="post">

<center>
<h1>註冊</h1>
<input type="text" name="uid" onkeyup="value=value.replace(/[\W]/g,'')" placeholder="請輸入您的帳號"><p>
<input type="password" name="upwd" onkeyup="value=value.replace(/[\W]/g,'')"  placeholder="請輸入您的密碼"><p>
<input type="email" name="email"   placeholder="請輸入您的e-mail"><p>
<input type="num" name="phnum"  onkeyup="value=value.replace(/[\W]/g,'')" placeholder="請輸入您的電話號碼"><p>


<input type="button"  onclick="check()"  value="提交">
<input type="reset"  onclick="reg.php"><p>

<a href="log.php">去登入頁面</a>

</center>
</form>
<?php
if(isset($_POST["uid"])){
	$uid=$_POST["uid"];
	$upwd=$_POST["upwd"];
	$email=$_POST["email"];
	$phnum=$_POST["phnum"];


require('include.inc');
$sql = 'CREATE DATABASE travel DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci';

mysqli_query($link,$sql);

mysqli_select_db($link,"midterm");
$sql = "INSERT INTO user(uid, upwd, email, phnum) VALUES ('$uid', '$upwd','$email','$phnum')";
mysqli_query($link, $sql);




}

?>
</body>
</html>